<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Postulación SERECI - ORURO</title>
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Custom fonts for this template-->
    <link href="<?php echo e(asset('index/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet">


    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
          rel="stylesheet">

    <!-- Custom styles for this template-->

    <link rel="stylesheet" href="<?php echo e(asset('index/css/sb-admin-2.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>">


    <?php echo $__env->yieldContent('styles'); ?>
</head>

<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">
            <!-- Topbar -->
            <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                <!-- Sidebar Toggle (Topbar) -->
                <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                    <i class="fa fa-bars"></i>
                </button>

                <!-- Topbar Search -->
                
                <!-- Topbar Navbar -->
                <ul class="navbar-nav ml-auto">

                    <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                    
                <?php if(auth()->guard()->check()): ?>
                    <!-- Nav Item - Alerts -->
                    
                    <div class="topbar-divider d-none d-sm-block"></div>

                    <!-- Nav Item - User Information -->
                    <li class="nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                           data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?php if(Auth::user()->credencializacion_fotografia !== 'foto'): ?>
                                <img class="img-profile rounded-circle" src="<?php echo e(Auth::user()->credencializacion_fotografia); ?>">
                            <?php else: ?>
                                <i class="fa fa-user"></i>&nbsp;&nbsp;
                            <?php endif; ?>
                            <span class="d-none d-lg-inline text-gray-600 small"><?php echo e(Auth::user()->nombres.' '.Auth::user()->apellido_paterno); ?></span>
                        </a>
                        <!-- Dropdown - User Information -->
                        <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                             aria-labelledby="userDropdown">

                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" data-toggle="modal" data-target="#logoutModal"
                               onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                <?php echo e(__('Cerrar Sesion')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                <?php endif; ?>
                </ul>

            </nav>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <?php echo $__env->yieldContent('content'); ?>
            <!-- /.container-fluid -->
        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; 2019 - <strong>SERECI ORURO</strong></span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->
    </div>
</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->

<!-- Bootstrap core JavaScript-->

<script src="<?php echo e(asset('index/vendor/jquery/jquery.min.js')); ?>"></script>
<script>
    var c=1;
    $(document).ready(function(){
        $('#sidebarToggleTop').click(function () {
            if (c == 1) {
                document.getElementById('accordionSidebar').style.display='block';
                c=0;
            }
            else{
                document.getElementById('accordionSidebar').style.display='none';
                c=1;
            }
        })
    });
</script>
<?php echo $__env->yieldContent('scripts'); ?>
<script src="<?php echo e(asset('index/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<!-- Core plugin JavaScript-->
<script src="<?php echo e(asset('index/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bs-custom-file-input.js')); ?>"></script>

<!-- Custom scripts for all pages-->
<!--<script src="index/js/sb-admin-2.min.js"></script>-->

<!-- Page level plugins -->
<!--<script src="index/vendor/chart.js/Chart.min.js"></script>-->

<!-- Page level custom scripts -->
<!--<script src="index/js/demo/chart-area-demo.js"></script>-->
<!--<script src="index/js/demo/chart-pie-demo.js"></script>-->


</body>

</html>
<?php /**PATH /opt/bitnami/apache2/htdocs/postulacion/resources/views/layouts/front.blade.php ENDPATH**/ ?>