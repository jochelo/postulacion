<?php $__env->startSection('content'); ?>
    <div class="container">
        <!-- Page Heading -->
        <div class="row">
            <div class="offset-3 col-lg-6">
                <div class="card">
                    <div class="card-header text-center">
                        <h4>DOCUMENTO DE CONSTANCIA DE REGISTRO DE POSTULACION</h4>
                    </div>
                    <div class="card-body text-center">
                        <a href="<?php echo e(url('reporte/solicitud')); ?>" target="_blank" class="btn btn-primary"><i
                                    class="	fas fa-download fa-sm text-white-50"></i> DESCARGAR REGISTRO DE POSTULACION</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br>
    <div class="container">
        <?php if(isset($testUser)): ?>
            <div class="row">
                <div class="offset-3 col-lg-6">
                    <div class="card">
                        <div class="card-header text-center">
                            <h4>DOCUMENTO DE CONSTANCIA DE EVALUACION</h4>
                        </div>
                        <div class="card-body text-center">
                            <a href="<?php echo e(url('reporte/test-aprobado')); ?>" target="_blank" class="btn btn-primary"><i
                                        class="	fas fa-download fa-sm text-white-50"></i> DESCARGAR EVALUACION</a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/bitnami/apache2/htdocs/postulacion/resources/views/home.blade.php ENDPATH**/ ?>