<?php $__env->startSection('content'); ?>
    <div class="container">
        <!--<a class="btn-plus btn btn-primary " href="<?php echo e(route("users.create")); ?>"><i class="fa fa-plus"></i></a>-->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header row">
                        <h3 class="col-md-6">Lista de <strong>Postulantes</strong></h3>
                        
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Foto</th>
                                    <th scope="col">Cargo</th>
                                    <th scope="col">Postulante</th>
                                    <th scope="col">Correo Electrónico</th>
                                    <th scope="col">Carnet</th>
                                    <th scope="col">Celular</th>
                                    <th scope="col">Grado Academico</th>
                                    <th scope="col">Titulo Academico</th>
                                    <th scope="col">Acciones</th>
                                </tr>
                                </thead>
                                <tbody id="t-body">
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="r-body">
                                        <td><?php echo e(($users->currentPage() - 1) * $users->perPage() + $loop->index + 1); ?></td>
                                        <td>
                                            <img src="<?php echo e($user->credencializacion_fotografia); ?>" height="125">
                                        </td>
                                        <td><?php echo e($user->cargo_descripcion); ?></td>
                                        <td><?php echo e($user->nombres.' '.$user->apellido_paterno.' '.$user->apellido_materno); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->numero_carnet); ?></td>
                                        <td><?php echo e($user->telefono_celular); ?></td>
                                        <td><?php echo e($user->academico_grado); ?></td>
                                        <td><?php echo e($user->academico_titulo); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <!--<a class="btn btn-border-none btn-sm btn-outline-success "
                                               href="<?php echo e(url('users/'.$user->user_id.'/edit')); ?>"
                                               data-toggle="tooltip"
                                               data-placement="top" title="Editar">
                                                <span class="fa fa-pencil-alt"></span>
                                            </a>-->
                                            <form class="float-right"
                                                  action="<?php echo e(route('users.destroy',$user->user_id)); ?>" method="POST"
                                                      onclick="return confirm('Estas seguro de que desea eliminar?')">
                                                    <?php echo e(csrf_field()); ?>

                                                <input type="hidden" name="_method" value="DELETE">
                                                <button type="submit"
                                                    class="btn btn-border-none btn-sm btn-outline-danger">
                                                <span class="fa fa-trash"></span>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <br>
                        <div class="row">
                            <div class="offset-md-3 col-lg-6 text-center">
                                <?php echo e($users->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function(){
            $("#s-postulantes").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $(".card-body .r-body").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/bitnami/apache2/htdocs/postulacion/resources/views/user/index.blade.php ENDPATH**/ ?>