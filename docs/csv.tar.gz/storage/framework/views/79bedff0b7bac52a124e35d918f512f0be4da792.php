<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                RESUMEN DE RESULTADOS POR CARGO
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>N.</th>
                            <th>Cargo</th>
                            <th>Postulantes</th>
                            <th>Evaluados</th>
                            <th>Ausentes</th>
                            <th>Total</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $resumenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resumen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->index + 1); ?></td>
                                <td><?php echo e($resumen['cargo']); ?></td>
                                <td><?php echo e($resumen['cantidad_postulantes']); ?></td>
                                <td><?php echo e($resumen['evaluados']); ?></td>
                                <td><?php echo e($resumen['ausentes']); ?></td>
                                <td><?php echo e($resumen['total']); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td><strong><?php echo e($total['descripcion']); ?></strong></td>
                            <td><strong><?php echo e($total['postulantes']); ?></strong></td>
                            <td><strong><?php echo e($total['evaluados']); ?></strong></td>
                            <td><strong><?php echo e($total['ausentes']); ?></strong></td>
                            <td><strong><?php echo e($total['total']); ?></strong></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/bitnami/apache2/htdocs/postulacion/resources/views/resultados/resumen.blade.php ENDPATH**/ ?>