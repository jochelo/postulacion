<style>
    button.nav-link {
        border: none;
        background: #e2872c;
        color: white;
    }
</style>
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(url('/')); ?>">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Postulaciones <small>SERECI - ORURO</small> </div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <?php if(auth()->guard()->check()): ?>

    <?php else: ?>
        <li class="nav-item active">
            <a class="nav-link" href="<?php echo e(url('/')); ?>">
                <span>INICIO</span></a>
        </li>
    <?php endif; ?>
    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Menu
    </div>
    <!-- Nav Item - Charts -->
    <?php if(auth()->guard()->guest()): ?>
   <!-- <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('login')); ?>">
            <i class="fas fa-fw fa-user"></i>
            <span>Iniciar Sesión</span></a>
    </li>-->
    <!-- Nav Item - Tables -
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('register')); ?>">
            <i class="fas fa-fw fa-sign-in-alt"></i>
            <span>Postulación</span></a>
    </li>-->
    <?php else: ?>
        <?php if(Auth::user()->es_admin): ?>
        <li class="nav-item">
            <form action="<?php echo e(url('/resumen-cargo')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <button class="nav-link" type="submit">
                    <i class="fas fa-fw fa-list-alt"></i>
                    <span>Resumen por Cargo</span></button>
            </form>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('/resumen')); ?>">
                <i class="fas fa-fw fa-file"></i>
                <span>Resumen General</span></a>
        </li>
        <li class="nav-item">
            <form action="<?php echo e(url('resultados')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <button class="nav-link" type="submit">
                    <i class="fas fa-fw fa-list-alt"></i>
                    <span>Resultados</span></button>
            </form>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('/tests')); ?>">
                <i class="fas fa-fw fa-file"></i>
                <span>Test</span></a>
        </li>
        <li class="nav-item">
            <form action="<?php echo e(url('preguntas-test')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="test_id" value="0">
                <button class="nav-link" type="submit">
                    <i class="fas fa-fw fa-list-alt"></i>
                    <span>Preguntas</span></button>
            </form>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('/users')); ?>">
                <i class="fas fa-fw fa-users"></i>
                <span>Postulantes</span></a>
        </li>
        <?php else: ?>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('/home')); ?>">
                <i class="fas fa-fw fa-file"></i>
                <span>Documentación</span></a>
        </li>

        <?php endif; ?>
    <?php endif; ?>
    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">
    <!-- Sidebar Toggler (Sidebar) -->
</ul>
<?php /**PATH /opt/bitnami/apache2/htdocs/postulacion/resources/views/layouts/nav.blade.php ENDPATH**/ ?>