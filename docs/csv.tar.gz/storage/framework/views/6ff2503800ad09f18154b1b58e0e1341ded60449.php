<?php $__env->startSection('content'); ?>
    <?php if($tests !== null): ?>
        <div class="container">
            <div class="row">
                <div class="offset-2 col-md-8">
                    <?php if($state === 'list'): ?>
                        <div class="card">
                            <div class="card-header">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <h3>Preguntas</h3>
                                    </div>
                                    <div class="col-lg-8">
                                        <form action="<?php echo e(url('preguntas-test')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <select name="test_id"
                                                    class="form-control"
                                                    id="test_id">
                                                <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        <?php if($test['test_id'] == $test_id): ?>
                                                        selected="selected"
                                                        <?php endif; ?>
                                                        value="<?php echo e($test['test_id']); ?>"><?php echo e($test['titulo']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo e(url('preguntas-test')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="state" value="create-pregunta">
                                    <input type="hidden" name="test_id" value="<?php echo e($test_id); ?>">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <input type="text" placeholder="Escriba su pregunta" name="pregunta_titulo" class="form-control" required>
                                        </div>
                                        <div class="col-md-4">
                                            <button type="submit" class="btn btn-primary btn-block">
                                                <i class="fa fa-question"></i> <strong>Registrar Pregunta</strong>
                                            </button>
                                        </div>
                                    </div>
                                </form>

                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                        <tr>
                                            <th>N.</th>
                                            <th>Pregunta</th>
                                            <th>Test</th>
                                            <th>Acciones</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->index + 1); ?></td>
                                                <td><?php echo e($pregunta['pregunta_titulo']); ?></td>
                                                <td><?php echo e($pregunta['test_titulo']); ?></td>
                                                <td>
                                                    <div class="row">
                                                        <div class="col-6">
                                                            <form action="<?php echo e(url('preguntas-test')); ?>" method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="state" value="list-respuestas">
                                                                <input type="hidden" name="test_id" value="<?php echo e($test_id); ?>">
                                                                <input type="hidden" name="pregunta"
                                                                       value="<?php echo e((string) $pregunta); ?>">
                                                                <button type="submit"
                                                                        title="Agregar Respuestas"
                                                                        class="btn btn-primary btn-sm btn-block">
                                                                    <strong>R </strong> <i class="fa fa-plus"></i>
                                                                </button>
                                                            </form>
                                                        </div>
                                                        <div class="col-6">
                                                            <form action="<?php echo e(url('preguntas-test')); ?>" method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="state" value="destroy-pregunta">
                                                                <input type="hidden" name="test_id" value="<?php echo e($test_id); ?>">
                                                                <input type="hidden" name="pregunta"
                                                                       value="<?php echo e((string) $pregunta); ?>">
                                                                <input type="hidden" name="pregunta_id"
                                                                       value="<?php echo e((int)$pregunta['pregunta_id']); ?>">
                                                                <button type="submit"
                                                                        title="Eliminar Pregunta"
                                                                        class="btn btn-danger btn-sm btn-block">
                                                                    <i class="fa fa-trash"></i>
                                                                </button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if($state === 'list-respuestas'): ?>
                        <div class="card">
                            <div class="card-header">
                                <h3><?php echo e($pregunta['test_titulo']); ?></h3>
                                <h4><strong><?php echo e($pregunta['pregunta_titulo']); ?></strong></h4>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo e(url('preguntas-test')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-8 form-group">
                                            <input type="hidden" name="pregunta_id"
                                                   value="<?php echo e((int)$pregunta['pregunta_id']); ?>">
                                            <input type="hidden" name="pregunta" value="<?php echo e((string) $pregunta); ?>">
                                            <input type="hidden" name="state" value="create-respuesta">
                                            <input type="hidden" name="test_id" value="<?php echo e($test_id); ?>">
                                            <input type="text" placeholder="Escribir respuesta" name="respuesta_descripcion" class="form-control" required>
                                        </div>
                                        <div class="col-md-4">
                                            <button class="btn btn-primary btn-block">
                                                <i class="fa fa-plus"></i> Agregar Respuesta
                                            </button>
                                        </div>
                                    </div>
                                </form>
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                        <tr>
                                            <th>N.</th>
                                            <th>Respuesta</th>
                                            <th>Correcto</th>
                                            <th>Acciones</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $pregunta['respuestas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->index + 1); ?></td>
                                                <td><?php echo e($respuesta['respuesta_descripcion']); ?></td>
                                                <td>
                                                    <?php if($respuesta['correcto']): ?>
                                                        <span class="text-primary">
                                                            <i class="fa fa-check"></i>
                                                        </span>
                                                    <?php else: ?>
                                                        <span class="text-danger">
                                                            <i class="fa fa-times"></i>
                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <div class="row">
                                                        <div class="col-6 text-center">
                                                            <?php if(!$respuesta['correcto']): ?>
                                                                <form action="<?php echo e(url('preguntas-test')); ?>" method="post">
                                                                    <?php echo csrf_field(); ?>
                                                                    <input type="hidden" name="test_id" value="<?php echo e($test_id); ?>">
                                                                    <input type="hidden" name="pregunta" value="<?php echo e((string) $pregunta); ?>">
                                                                    <input type="hidden" name="pregunta_id" value="<?php echo e($pregunta['pregunta_id']); ?>">
                                                                    <input type="hidden" name="respuesta_id" value="<?php echo e($respuesta['respuesta_id']); ?>">
                                                                    <input type="hidden" name="state" value="set-respuesta-correcta">
                                                                    <button
                                                                        title="Cambiar Respuesta Correcta"
                                                                        type="submit"
                                                                        class="btn btn-primary btn-sm btn-block">
                                                                        <i class="fa fa-check"></i>
                                                                    </button>
                                                                </form>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="col-6 text-center">
                                                            <?php if(!$respuesta['correcto']): ?>
                                                            <form action="<?php echo e(url('preguntas-test')); ?>" method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="test_id" value="<?php echo e($test_id); ?>">
                                                                <input type="hidden" name="pregunta" value="<?php echo e((string) $pregunta); ?>">
                                                                <input type="hidden" name="pregunta_id" value="<?php echo e($pregunta['pregunta_id']); ?>">
                                                                <input type="hidden" name="respuesta_id" value="<?php echo e($respuesta['respuesta_id']); ?>">
                                                                <input type="hidden" name="state" value="destroy-respuesta">
                                                                <button
                                                                    title="Eliminar Respuesta"
                                                                    type="submit"
                                                                    class="btn btn-danger btn-sm btn-block">
                                                                    <i class="fa fa-trash"></i>
                                                                </button>
                                                            </form>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="row">
                                    <div class="col-12 text-center">
                                        <a href="<?php echo e(url('preguntas-test')); ?>" class="btn btn-primary">
                                            <i class="fa fa-home"></i> Volver a listado de preguntas
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <script>
                        var select = document.getElementById('test_id');
                        select.addEventListener('change', function () {
                            this.form.submit();
                        }, false);
                    </script>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <?php if($tests === null): ?>
        <div class="container">
            <div class="alert alert-primary text-center">
                <h3>No existen tests registrados</h3>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/bitnami/apache2/htdocs/postulacion/resources/views/pregunta/index.blade.php ENDPATH**/ ?>