<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        RESUMEN DE EVALUACIONES
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th>Total</th>
                                    <th>Aprobados (>50%)</th>
                                    <th>Reprobados (<=50%)</th>
                                    <th>Con Nota 0</th>
                                    <th>Con fallas en sistema</th>
                                    <th>No siguieron instrucciones</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td><strong><?php echo e($resumen['total']); ?></strong></td>
                                    <td><?php echo e($resumen['aprobados']); ?></td>
                                    <td><?php echo e($resumen['reprobados']); ?></td>
                                    <td><?php echo e($resumen['con_nota_cero']); ?></td>
                                    <td><?php echo e($resumen['con_problemas_sistema']); ?></td>
                                    <td><?php echo e($resumen['no_siguio_instrucciones']); ?></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        POSTULANTES QUE HICIERON MAL USO DEL SISTEMA <br>
                        <small>Refrescado de la página, durante la evaluación online</small>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th>N.</th>
                                    <th>Numero de Carnet</th>
                                    <th>Postulante</th>
                                    <th>Celular</th>
                                </tr>
                                </thead>
                                <tbody>

                                <?php $__currentLoopData = $postulantes_no_siguieron_instrucciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postulante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($postulante['numero_carnet']); ?></td>
                                        <td><?php echo e($postulante['apellido_paterno']); ?> <?php echo e($postulante['apellido_materno']); ?> <?php echo e($postulante['nombres']); ?></td>
                                        <td><?php echo e($postulante['telefono_celular']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        POSTULANTES CON FALLAS EN EL SISTEMA <br>
                        <small>Error temporal de sistema por latencia en cargado de preguntas hasta antes de las 10am</small>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>N.</th>
                                    <th>Numero de Carnet</th>
                                    <th>Postulante</th>
                                    <th>Celular</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $postulantes_con_problemas_sistema; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postulante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($postulante['numero_carnet']); ?></td>
                                        <td><?php echo e($postulante['apellido_paterno']); ?> <?php echo e($postulante['apellido_materno']); ?> <?php echo e($postulante['nombres']); ?></td>
                                        <td><?php echo e($postulante['telefono_celular']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/bitnami/apache2/htdocs/postulacion/resources/views/test-user/resumen.blade.php ENDPATH**/ ?>