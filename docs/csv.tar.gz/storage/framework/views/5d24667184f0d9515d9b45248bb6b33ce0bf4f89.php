<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                RESULTADOS EVALUACION ONLINE POR CARGO
            </div>
            <div class="card-body">
                <form action="<?php echo e(url('/resultados')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="form-group">
                                <select class="form-control" name="cargo_id" id="cargo_id">
                                    <option <?php if($cargo_id == 0): ?>
                                            selected="selected"
                                            <?php endif; ?>
                                            value="0">Todos</option>
                                    <?php $__currentLoopData = $cargos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cargo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if($cargo_id == $cargo['cargo_id']): ?>
                                                selected="selected"
                                                <?php endif; ?>
                                                value="<?php echo e($cargo['cargo_id']); ?>"><?php echo e($cargo['cargo_descripcion']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <button type="submit" class="btn btn-primary btn-block">GENERAR</button>
                        </div>
                    </div>
                </form>
                <br>
                <form action="<?php echo e(url('/resultados-csv')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="form-group">
                                <select class="form-control" name="cargo_id" id="cargo_id">
                                    <option <?php if($cargo_id == 0): ?>
                                            selected="selected"
                                            <?php endif; ?>
                                            value="0">Todos</option>
                                    <?php $__currentLoopData = $cargos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cargo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if($cargo_id == $cargo['cargo_id']): ?>
                                                selected="selected"
                                                <?php endif; ?>
                                                value="<?php echo e($cargo['cargo_id']); ?>"><?php echo e($cargo['cargo_descripcion']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <button type="submit" class="btn btn-secondary btn-block">GENERAR CSV</button>
                        </div>
                    </div>
                </form>
                <br>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>N.</th>
                            <th>Postulante</th>
                            <th>Celular</th>
                            <th>Cedula de Identidad</th>
                            <th>Cargo</th>
                            <th>Nota</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $test_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index + 1); ?></td>
                            <td><?php echo e($test_user['user']['apellido_paterno']); ?> <?php echo e($test_user['user']['apellido_materno']); ?> <?php echo e($test_user['user']['nombres']); ?></td>
                            <td><?php echo e($test_user['user']['telefono_celular']); ?></td>
                            <td><?php echo e($test_user['user']['numero_carnet']); ?></td>
                            <td><?php echo e($test_user['user']['cargo_descripcion']); ?></td>
                            <td><?php echo e($test_user['nota']); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script>
        var render = document.getElementById('render');
        render.addEventListener('click', function () {
            var test_users = document.getElementById('test_users');
            console.log(test_users);
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/bitnami/apache2/htdocs/postulacion/resources/views/resultados/resultados.blade.php ENDPATH**/ ?>